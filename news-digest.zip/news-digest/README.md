# 📰 글로벌 뉴스 다이제스트

매일 아침 7시, 전 세계 주요 언론사의 경제/금융/IT/정치 뉴스를 자동으로 이메일로 받아보세요.  
**완전 무료** (GitHub Actions + Gmail SMTP)

---

## 📋 수집 대상 언론사 (26개)

| 국가 | 언론사 |
|------|--------|
| 🇺🇸 미국 | NYT, Washington Post, CNN, Fox News, WSJ, Financial Times, AP |
| 🇬🇧 영국 | The Times, Reuters |
| 🌐 국제 | EIN Presswire |
| 🇯🇵 일본 | 朝日新聞, 読売新聞, 日経Asia |
| 🇨🇳 중국 | Global Times, People's Daily |
| 🇯🇴 중동 | Jordan Times |
| 🇫🇷 프랑스 | Le Monde, Le Figaro |
| 🇩🇪 독일 | Der Spiegel, Die Welt, FAZ |

**카테고리**: 💹 경제/금융 · 💻 기술/IT · 🏛️ 정치/외교 · 🌍 일반/국제

---

## 🚀 설치 방법 (5단계)

### 1단계 — GitHub 저장소 생성

1. [github.com](https://github.com) 로그인
2. 우상단 **+** → **New repository**
3. Repository name: `news-digest` (Private 권장)
4. **Create repository** 클릭

### 2단계 — 파일 업로드

다음 파일/폴더 구조를 그대로 업로드하세요:

```
news-digest/
├── .github/
│   └── workflows/
│       └── daily_digest.yml   ← GitHub Actions 워크플로우
├── src/
│   └── news_digest.py         ← 메인 스크립트
├── requirements.txt           ← 패키지 목록
└── README.md
```

> **팁**: GitHub 웹에서 `Add file` → `Upload files`로 드래그앤드롭 가능

### 3단계 — Gmail 앱 비밀번호 발급

> ⚠️ 일반 Gmail 비밀번호가 아닌 **앱 비밀번호**가 필요합니다.

1. [myaccount.google.com](https://myaccount.google.com) 접속
2. **보안** → **2단계 인증** 활성화 (미설정 시 먼저 설정)
3. **보안** → 검색창에 **"앱 비밀번호"** 검색 → 클릭
4. 앱 이름: `news-digest` 입력 → **만들기**
5. 생성된 **16자리 비밀번호** 복사해두기 (예: `abcd efgh ijkl mnop`)

### 4단계 — GitHub Secrets 등록

1. GitHub 저장소 → **Settings** → **Secrets and variables** → **Actions**
2. **New repository secret** 버튼으로 아래 3개 등록:

| Secret 이름 | 값 | 예시 |
|-------------|-----|------|
| `GMAIL_ADDRESS` | 발신 Gmail 주소 | `yourname@gmail.com` |
| `GMAIL_APP_PASSWORD` | 앱 비밀번호 (공백 없이) | `abcdefghijklmnop` |
| `RECIPIENT_EMAILS` | 수신 이메일 (콤마로 여러 개 가능) | `you@gmail.com,friend@naver.com` |

### 5단계 — 테스트 실행

1. 저장소 → **Actions** 탭
2. **📰 Daily Global News Digest** 클릭
3. **Run workflow** → **Run workflow** 버튼 클릭
4. 1~3분 후 이메일 확인 ✉️

---

## ⏰ 자동 실행 시간

```
매일 오전 7:00 KST (한국 시간)
```

`daily_digest.yml`의 cron 값을 바꾸면 시간 변경 가능:

| 원하는 시간 (KST) | cron 값 |
|-------------------|---------|
| 오전 6시 | `0 21 * * *` |
| **오전 7시** (기본값) | `0 22 * * *` |
| 오전 8시 | `0 23 * * *` |
| 오전 9시 | `0 0 * * *` |

---

## 🔧 커스터마이징

### 언론사 추가/제거
`src/news_digest.py`의 `SOURCES` 딕셔너리에서 RSS URL 추가/삭제

### 카테고리 키워드 수정
`KEYWORDS` 딕셔너리에서 원하는 키워드 추가

### 소스당 기사 수 조절
```python
MAX_ITEMS_PER_SOURCE = 5  # 원하는 숫자로 변경
```

---

## 💰 비용

| 항목 | 비용 |
|------|------|
| GitHub Actions | **무료** (월 2,000분 제공, 약 3분/회 사용) |
| Gmail SMTP | **무료** |
| RSS 수집 | **무료** |
| **합계** | **₩0** |

---

## ❓ 문제해결

**이메일이 스팸함에 들어가요**  
→ 수신함에서 "스팸 아님" 처리 한 번만 하면 이후 정상 수신됩니다.

**일부 언론사 기사가 안 와요**  
→ 일부 언론사(NYT, WSJ 등)는 RSS를 제한하거나 변경할 수 있습니다. Actions 로그에서 ⚠️ 경고 확인 후 URL 업데이트하세요.

**앱 비밀번호 오류**  
→ 공백 없이 16자리만 입력했는지 확인하세요.
